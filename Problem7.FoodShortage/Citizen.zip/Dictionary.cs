﻿namespace Problem7.FoodShortage
{
	internal class Dictionary<T>
	{
		public Dictionary()
		{
		}
	}
}