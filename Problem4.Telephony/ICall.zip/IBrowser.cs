﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem4.Telephony
{
   public interface IBrowser
    {
		void Browse(List<string> sites);
    }
}
