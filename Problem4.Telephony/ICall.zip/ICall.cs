﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem4.Telephony
{
    interface ICall
    {
		void Calling(List<string> numbers);
    }
}
